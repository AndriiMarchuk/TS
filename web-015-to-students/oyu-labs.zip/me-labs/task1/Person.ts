
export class Person
{
    private _name: string;

    constructor(public name: string)
    {
        this._name = name;
    }

    getInfo()
    {
        return "Person: " + this._name;
    }

    getInfoInterpolation()
    {
        return `person: ${this._name}`;
    }
}