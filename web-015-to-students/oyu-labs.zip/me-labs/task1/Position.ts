
export class Position
{

}