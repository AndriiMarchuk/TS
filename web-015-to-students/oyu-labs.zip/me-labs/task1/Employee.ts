
import {Person} from "./Person";
import {Position} from "./Position";

export class Employee extends Person
{
    private _position: Position;
    private _salary: number;

    constructor(_name: string, public position: string, public salary: number)
    {
        super(name);
        this._position = position;
        this._salary = salary;
    }


    getInfo(): string
    {
        return super.getInfo() + " " + this._position + " " + this._salary;
    }
}