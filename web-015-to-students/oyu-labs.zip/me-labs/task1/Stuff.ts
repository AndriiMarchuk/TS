
import {Employee} from "./Employee";
export class Stuff
{
    static employees: Array<Employee> = [];

    static add(employee: Employee)
    {
        this.employees.push(employee);
    }

    static list(): Employee[]
    {
        return [...this.employees];
    }

}