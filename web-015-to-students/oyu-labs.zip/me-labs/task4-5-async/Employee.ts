
import {Person} from "./Person";
import {Position} from "./Position";

export class Employee extends Person
{
    private _position: Position;
    private _salary: number;

    constructor(_name: string, public position: string, public salary: number)
    {
        super(name);
        this._position = position;
        this._salary = salary;
    }


    getInfo(): string
    {
        return super.getInfo() + " " + this._position + " " + this._salary;
    }

    bonus(): Promise<number>
    {
        var bonus = Math.round(Math.random() * 1000);
        return new Promise((resolve, reject) =>
            setTimeout(() =>
                    bonus < 700 ? resolve(bonus) : reject(bonus),
                    Math.random() * 3000)
            );
    }

    total(): Promise<number>
    {
        return new Promise((resolve, reject) => this.bonus()
            .then(bonus => resolve(bonus + this.salary))
            .catch(bonus => reject(bonus)));
    }

}