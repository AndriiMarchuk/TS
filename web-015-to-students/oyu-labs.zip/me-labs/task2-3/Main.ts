
import {Stuff} from "./Stuff";
import {Employee} from "./Employee";

export default function ()
{
    Stuff.add(new Employee("John", "manager", 1000));
    Stuff.add(new Employee("Bill", "developer", 3000));
    Stuff.add(new Employee("James", "tester", 1500));

    let stuff: Employee[] = Stuff.list();

    let html = "";

    for (let e of stuff)
    {
        html += e.getInfo() + "<br>";
    }

    html += `<br><br>Avg salary: ${Stuff.avgSalary()}`;


    html += "<br><br>";

    for (let e of stuff)
    {
        e.total().then(total =>
        {
            html += `${e.name} total: ${total} <br>`;
            render(html);
        });

    }

    render(html);
}

function render(html: string)
{
    document.getElementById("employees").innerHTML = html;
}