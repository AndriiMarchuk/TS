var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
System.register("Person", [], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Person;
    return {
        setters: [],
        execute: function () {
            Person = (function () {
                function Person(name) {
                    this.name = name;
                    this._name = name;
                }
                Person.prototype.getInfo = function () {
                    return "Person: " + this._name;
                };
                Person.prototype.getInfoInterpolation = function () {
                    return "person: " + this._name;
                };
                return Person;
            }());
            exports_1("Person", Person);
        }
    };
});
System.register("Position", [], function (exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var Position;
    return {
        setters: [],
        execute: function () {
            Position = (function () {
                function Position() {
                }
                return Position;
            }());
            exports_2("Position", Position);
        }
    };
});
System.register("Employee", ["Person"], function (exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    var Person_1, Employee;
    return {
        setters: [
            function (Person_1_1) {
                Person_1 = Person_1_1;
            }
        ],
        execute: function () {
            Employee = (function (_super) {
                __extends(Employee, _super);
                function Employee(_name, position, salary) {
                    var _this = _super.call(this, name) || this;
                    _this.position = position;
                    _this.salary = salary;
                    _this._position = position;
                    _this._salary = salary;
                    return _this;
                }
                Employee.prototype.getInfo = function () {
                    return _super.prototype.getInfo.call(this) + " " + this._position + " " + this._salary;
                };
                Employee.prototype.bonus = function () {
                    return new Promise(function (resolve) {
                        return setTimeout(function () {
                            return resolve(Math.round(Math.random() * 1000));
                        }, Math.random() * 3000);
                    });
                };
                Employee.prototype.total = function () {
                    var _this = this;
                    return new Promise(function (resolve) { return _this.bonus().then(function (bonus) { return resolve(bonus + _this.salary); }); });
                };
                return Employee;
            }(Person_1.Person));
            exports_3("Employee", Employee);
        }
    };
});
System.register("Stuff", [], function (exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var Stuff;
    return {
        setters: [],
        execute: function () {
            Stuff = (function () {
                function Stuff() {
                }
                Stuff.add = function (employee) {
                    this.employees.push(employee);
                };
                Stuff.list = function () {
                    return this.employees.slice();
                };
                Stuff.avgSalary = function () {
                    return Math.round(this.employees.map(function (e) { return e.salary; }).reduce(function (a, b) { return a + b; }) / this.employees.length);
                };
                Stuff.employees = [];
                return Stuff;
            }());
            exports_4("Stuff", Stuff);
        }
    };
});
System.register("Main", ["Stuff", "Employee"], function (exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    function default_1() {
        Stuff_1.Stuff.add(new Employee_1.Employee("John", "manager", 1000));
        Stuff_1.Stuff.add(new Employee_1.Employee("Bill", "developer", 3000));
        Stuff_1.Stuff.add(new Employee_1.Employee("James", "tester", 1500));
        var stuff = Stuff_1.Stuff.list();
        var html = "";
        for (var _i = 0, stuff_1 = stuff; _i < stuff_1.length; _i++) {
            var e = stuff_1[_i];
            html += e.getInfo() + "<br>";
        }
        html += "<br><br>Avg salary: " + Stuff_1.Stuff.avgSalary();
        html += "<br><br>";
        var _loop_1 = function (e) {
            e.total().then(function (total) {
                html += e.name + " total: " + total + " <br>";
                render(html);
            });
        };
        for (var _a = 0, stuff_2 = stuff; _a < stuff_2.length; _a++) {
            var e = stuff_2[_a];
            _loop_1(e);
        }
        render(html);
    }
    exports_5("default", default_1);
    function render(html) {
        document.getElementById("employees").innerHTML = html;
    }
    var Stuff_1, Employee_1;
    return {
        setters: [
            function (Stuff_1_1) {
                Stuff_1 = Stuff_1_1;
            },
            function (Employee_1_1) {
                Employee_1 = Employee_1_1;
            }
        ],
        execute: function () {
        }
    };
});
//# sourceMappingURL=bundle.js.map