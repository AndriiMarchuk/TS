
import {Person} from "./Person";
import {Position} from "./Position";

export class Employee extends Person
{
    private _position: Position;
    private _salary: number;

    constructor(_name: string, public position: string, public salary: number)
    {
        super(name);
        this._position = position;
        this._salary = salary;
    }


    getInfo(): string
    {
        return super.getInfo() + " " + this._position + " " + this._salary;
    }

    // TASK 3

    bonus(): Promise<number>
    {
        return new Promise(resolve =>
            setTimeout(() =>
                    resolve(Math.round(Math.random() * 1000)),
                    Math.random() * 3000)
            );
    }

    total(): Promise<number>
    {
        return new Promise(resolve => this.bonus().then(bonus => resolve(bonus + this.salary)));
    }

}