
import {Employee} from "./Employee";
export class Stuff
{
    static employees: Array<Employee> = [];

    static add(employee: Employee)
    {
        this.employees.push(employee);
    }

    static list(): Employee[]
    {
        return [...this.employees];
    }

    // Task 2
    static avgSalary()
    {
        return Math.round(
          this.employees.map(e => e.salary).reduce((a, b) => a + b) / this.employees.length
        );
    }



}