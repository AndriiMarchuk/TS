
import {Person} from "./Person";
import {Position} from "./Position";
import {Range} from "./Range";

export class Employee extends Person
{
    private _position: Position;
    private _salary: number;
    private _age: number;

    constructor(_name: string, public position: string, public salary: number)
    {
        super(name);
        this._position = position;
        this._salary = salary;
    }


    getInfo(): string
    {
        return super.getInfo() + " " + this._position + " " + this._salary;
    }

    bonus(): Promise<number>
    {
        var bonus = Math.round(Math.random() * 1000);
        return new Promise((resolve, reject) =>
            setTimeout(() =>
                    bonus < 700 ? resolve(bonus) : reject(bonus),
                    Math.random() * 3000)
            );
    }

    total(): Promise<number>
    {
        return new Promise((resolve, reject) => this.bonus()
            .then(bonus => resolve(bonus + this.salary))
            .catch(bonus => reject(bonus)));
    }

    // @Range(18, 80)
    get age(): number
    {
        return this._age;
    }

    @Range(18, 80)
    set age(age: number)
    {
        this._age = age;
    }
}