
import {Stuff} from "./Stuff";
import {Employee} from "./Employee";

let html = "";

export default function ()
{
    Stuff.add(new Employee("John", "manager", 1000));
    Stuff.add(new Employee("Bill", "developer", 3000));
    Stuff.add(new Employee("James", "tester", 1500));


    let stuff: Employee[] = Stuff.list();

    for (let e of stuff)
    {
        html += e.getInfo() + "<br>";
    }

    html += `<br><br>Avg salary: ${Stuff.avgSalary()}`;


    html += "<br><br>";

    render();

    for (let e of stuff)
    {
        e.total()
            .then(total =>
            {
                html += `${e.name} total: ${total} <br>`;
                render();
            })
            .catch(bonus =>
            {
                html += `${e.name} too big bonus generated: ${bonus} <br>`;
                render();
            });

    }


    let grandFather = new Employee('Ben', 'manager', 1000);
    try
    {
        grandFather.age = 60;
        console.log(grandFather.age);

        grandFather.age = 160;
    }
    catch (e)
    {
        console.error(e);
    }
}

function render()
{
    document.getElementById("employees").innerHTML = html;
}
