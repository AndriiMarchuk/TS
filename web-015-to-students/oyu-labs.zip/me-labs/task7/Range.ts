
export function Range(from: number, to: number): any
{
    return function<T extends number> (targetObject: any, propName: string, descriptor: any)
    {
        console.log('desc ' + JSON.stringify(descriptor));

        let oldFunc = descriptor.set;

        descriptor.set = function ()
        {
            let value = arguments[0];
            if (value < from || value > to)
            {
                throw new Error('Wrong value: ' + value + ', valid range(' + from + ', ' + to);
            }
            oldFunc.apply(targetObject, arguments);
            return descriptor;
        }
    }
}