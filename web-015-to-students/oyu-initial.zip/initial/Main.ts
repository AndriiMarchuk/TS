
export default function ()
{

    // document.getElementById("employees").innerHTML = "Hello";
    console.log("initialized");
}

