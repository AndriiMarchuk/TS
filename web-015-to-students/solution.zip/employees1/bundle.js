var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
System.register("Person", [], function (exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Person;
    return {
        setters: [],
        execute: function () {
            Person = (function () {
                function Person(name) {
                    this.name = name;
                }
                Person.prototype.getInfo = function () {
                    return "person: " + this.name;
                };
                return Person;
            }());
            exports_1("Person", Person);
        }
    };
});
System.register("Position", [], function (exports_2, context_2) {
    "use strict";
    var __moduleName = context_2 && context_2.id;
    var Position;
    return {
        setters: [],
        execute: function () {
            (function (Position) {
                Position[Position["MANAGER"] = 0] = "MANAGER";
                Position[Position["DEVELOPER"] = 1] = "DEVELOPER";
                Position[Position["DIRECTOR"] = 2] = "DIRECTOR";
            })(Position || (Position = {}));
            exports_2("Position", Position);
        }
    };
});
System.register("Range", [], function (exports_3, context_3) {
    "use strict";
    var __moduleName = context_3 && context_3.id;
    function Range(from, to) {
        return function (target, key, desc) {
            var oldFunc = desc.set;
            desc.set = function () {
                var value = arguments[0];
                if (value < from || value > to)
                    throw new Error("Wrong value of field " + key);
                oldFunc.apply(target, arguments);
            };
            return desc;
        };
    }
    exports_3("Range", Range);
    return {
        setters: [],
        execute: function () {
        }
    };
});
System.register("Employee", ["Person", "Position", "Range"], function (exports_4, context_4) {
    "use strict";
    var __moduleName = context_4 && context_4.id;
    var Person_1, Position_1, Range_1, Employee;
    return {
        setters: [
            function (Person_1_1) {
                Person_1 = Person_1_1;
            },
            function (Position_1_1) {
                Position_1 = Position_1_1;
            },
            function (Range_1_1) {
                Range_1 = Range_1_1;
            }
        ],
        execute: function () {
            Employee = (function (_super) {
                __extends(Employee, _super);
                function Employee(_name, position, salary) {
                    var _this = _super.call(this, _name) || this;
                    _this.position = position;
                    _this.salary = salary;
                    return _this;
                }
                Employee.prototype.getInfo = function () {
                    return _super.prototype.getInfo.call(this) + (" " + Position_1.Position[this.position] + " " + this.salary);
                };
                Employee.prototype.bonus = function () {
                    return new Promise(function (resolve) {
                        return setTimeout(function () { return resolve(Math.round(Math.random() * 1000)); }, 1000);
                    });
                };
                Employee.prototype.total = function () {
                    var _this = this;
                    return new Promise(function (resolve) {
                        return _this.bonus().then(function (bonus) {
                            return resolve(bonus + _this.salary);
                        });
                    });
                };
                Object.defineProperty(Employee.prototype, "age", {
                    get: function () {
                        return this._age;
                    },
                    set: function (_age) {
                        this._age = _age;
                    },
                    enumerable: true,
                    configurable: true
                });
                return Employee;
            }(Person_1.Person));
            __decorate([
                Range_1.Range(18, 80)
            ], Employee.prototype, "age", null);
            exports_4("Employee", Employee);
        }
    };
});
System.register("Employees", [], function (exports_5, context_5) {
    "use strict";
    var __moduleName = context_5 && context_5.id;
    var Employees;
    return {
        setters: [],
        execute: function () {
            Employees = (function () {
                function Employees() {
                }
                Employees.add = function (employee) {
                    Employees.employees.push(employee);
                };
                Employees.list = function () {
                    return Employees.employees.slice();
                };
                Employees.sum = function (f) {
                    return Employees.employees.map(f).reduce(function (x, y) { return x + y; });
                };
                return Employees;
            }());
            Employees.employees = [];
            exports_5("Employees", Employees);
        }
    };
});
System.register("main", ["Employees", "Employee", "Position"], function (exports_6, context_6) {
    "use strict";
    var __moduleName = context_6 && context_6.id;
    function default_1() {
        Employees_1.Employees.add(new Employee_1.Employee("John", Position_2.Position.MANAGER, 1000));
        Employees_1.Employees.add(new Employee_1.Employee("Bill", Position_2.Position.DEVELOPER, 5000));
        Employees_1.Employees.add(new Employee_1.Employee("James", Position_2.Position.DIRECTOR, 4000));
        var older = new Employee_1.Employee("Old", Position_2.Position.MANAGER, 5000);
        try {
            older.age = 100;
        }
        catch (e) {
            console.log(e);
        }
        Employees_1.Employees.add(older);
        var employees = Employees_1.Employees.list();
        var _loop_1 = function (e) {
            e.total().then(function (total) {
                html += e.name + " total: " + total + "<br>";
                render();
            });
        };
        for (var _i = 0, employees_1 = employees; _i < employees_1.length; _i++) {
            var e = employees_1[_i];
            _loop_1(e);
        }
        function render() {
            document.getElementById("employees").innerHTML = html;
        }
        var html = "";
        for (var _a = 0, employees_2 = employees; _a < employees_2.length; _a++) {
            var e = employees_2[_a];
            html += e.getInfo() + "<br>";
        }
        html += "Total salary: " + Employees_1.Employees.sum(function (e) { return e.salary; });
        render();
    }
    exports_6("default", default_1);
    var Employees_1, Employee_1, Position_2;
    return {
        setters: [
            function (Employees_1_1) {
                Employees_1 = Employees_1_1;
            },
            function (Employee_1_1) {
                Employee_1 = Employee_1_1;
            },
            function (Position_2_1) {
                Position_2 = Position_2_1;
            }
        ],
        execute: function () {
        }
    };
});
//# sourceMappingURL=bundle.js.map