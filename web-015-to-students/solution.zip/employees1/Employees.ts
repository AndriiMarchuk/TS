import {Employee} from "./Employee"
import {Range} from "./Range"

export class Employees {
    static employees:Array<Employee>=[];

    static add(employee:Employee) {
        Employees.employees.push(employee);
    }

    static list():Employee[] {
        return [...Employees.employees];
    }

    // static *[Symbol.iterator]() {
    //     yield* Employees.employees;
    // }

    static sum(f:(e:Employee)=>number):number {
        return Employees.employees.map(f).reduce((x,y)=>x+y);
    }
}