import {Employees} from "./Employees"
import {Employee} from "./Employee"
import {Position} from "./Position"

export default function() {
    Employees.add(new Employee("John",Position.MANAGER,1000));
    Employees.add(new Employee("Bill",Position.DEVELOPER,5000));
    Employees.add(new Employee("James",Position.DIRECTOR,4000));

    let older = new Employee("Old", Position.MANAGER, 5000);
    try {
        older.age=100;
    } catch(e) {
        console.log(e);
    }
    Employees.add(older);

    let employees:Employee[] = Employees.list()

    for (let e of employees) {
        e.total().then(total=> {
                html += `${e.name} total: ${total}<br>`
                render()
            }
        )
    }

    function render() {
        document.getElementById("employees").innerHTML = html;
    }


    let html = "";
    for (let e of employees) {
        html += e.getInfo()+"<br>"
    }
    html += "Total salary: "+Employees.sum(e=>e.salary);

    render();


    /*
    async function printBonus() {
        html += "<br>Async/await version:<br>";
        for (let e of Employees.list()) {
            let bonus = await e.bonus();
            html += `${e.name} bonus: ${bonus} 
              total: ${e.salary+bonus}<br>`;
            render();
        }
    }

    printBonus();
    */
}

