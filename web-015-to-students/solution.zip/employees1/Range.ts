export function Range(from:number, to:number):any {
    return function<T extends number>(target:any, key:string, desc:any) {
        let oldFunc = desc.set;
        desc.set = function () {
            let value = arguments[0];
            if (value<from || value>to) throw new Error("Wrong value of field "+key);
            oldFunc.apply(target,arguments);
        }
        return desc;
    }
}
