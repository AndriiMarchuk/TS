import {Person} from "./Person"
import {Position} from "./Position";
import {Range} from "./Range";

export class Employee extends Person {

    _age: number;

    constructor(_name:string, public position:Position, public salary:number) {
        super(_name);
    }

    getInfo() {
        return super.getInfo()+` ${Position[this.position]} ${this.salary}`
    }

    bonus():Promise<number> {
        return new Promise(resolve=>
            setTimeout(
                ()=>resolve(Math.round(Math.random()*1000)),
                1000))
    }

    total() {
        return new Promise(resolve=>
            this.bonus().then(bonus=>
                resolve(bonus+this.salary)))
    }

    @Range(18,80)
    set age(_age:number) {
        this._age = _age;
    }
    get age():number {
        return this._age;
    }
}
