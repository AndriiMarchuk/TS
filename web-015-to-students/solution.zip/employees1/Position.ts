export enum Position {
    MANAGER,
    DEVELOPER,
    DIRECTOR
}